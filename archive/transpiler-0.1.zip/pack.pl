name('transpiler').
title('A universal translator for programming languages').

version('0.1').
download('https://github.com/jarble/universal-transpiler/transpiler-0.1.zip').


author('Anderson Green','jarble@gmail.com').
packager('Anderson Green','jarble@gmail.com').
maintainer('Anderson Green','jarble@gmail.com').

home('https://github.com/jarble/universal-transpiler/').
